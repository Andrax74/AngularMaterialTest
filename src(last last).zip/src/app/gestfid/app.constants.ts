export const baseURL = "http://localhost:5070/api/clienti";
